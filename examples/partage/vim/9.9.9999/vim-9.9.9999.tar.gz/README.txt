Archive de demonstration deployee par Workstation Tooler.
